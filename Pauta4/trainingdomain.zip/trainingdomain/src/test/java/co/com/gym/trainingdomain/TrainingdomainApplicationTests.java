package co.com.gym.trainingdomain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingdomainApplicationTests {

	@Test
	void contextLoads() {
	}

}
