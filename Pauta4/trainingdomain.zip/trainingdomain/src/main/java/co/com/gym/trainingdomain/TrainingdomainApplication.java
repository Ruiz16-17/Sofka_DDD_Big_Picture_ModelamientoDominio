package co.com.gym.trainingdomain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingdomainApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingdomainApplication.class, args);
	}

}
